import pygame


class Background:

    def __init__(self):
        self.image = pygame.image.load("blue-background.jpg")