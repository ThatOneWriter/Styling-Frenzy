import pygame


class Person:

    def __init__(self):
        self.image = pygame.image.load("blue-background.jpg")